window.onload = function() {
  const loader = document.getElementById('loading-wrapper');
  loader.classList.add('completed');
}